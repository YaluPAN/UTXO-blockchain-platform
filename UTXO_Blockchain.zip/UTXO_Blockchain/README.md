1. pip install -r requirements.txt
2. Find "sys.path.append("/Users/.../UTXO_Miner")" in blockchain.py ("Blockchain/Backend/core" directory) and account.py ("Blockchain/Backend/client" directory), replace with your system path.
3. Go to blockchain.py file inside "Blockchain/Backend/core" directory and run it.
4. Visit http://127.0.0.1:5900/.